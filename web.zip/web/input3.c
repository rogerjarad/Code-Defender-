#include <stdio.h>

int main () {
   char str[50];

   printf("Enter a string : ");
   gets(str);

   sprintf("You entered: %s", str);

   return(0);
}

